#include "TextureLoader.h"
using namespace std;

TextureLoader::texture TextureLoader::textures;

uint32 TextureLoader::LoadTex(const string& path) {
	// �e je ta tekstura �e nalo�ena vrne njen id
	for(tex_iter i = textures.begin(); i != textures.end(); ++i) {
		if((*i).first == path) return (*i).second;
	}

	uint32 id = SOIL_load_OGL_texture(
			path.c_str(),
			SOIL_LOAD_RGBA,
			SOIL_CREATE_NEW_ID,
			SOIL_FLAG_INVERT_Y);
	textures[path] = id;
	return id;
}
